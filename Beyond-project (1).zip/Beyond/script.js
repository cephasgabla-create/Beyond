const videos = document.querySelectorAll(".video");
const likeButtons = document.querySelectorAll(".like-btn");
const commentButtons = document.querySelectorAll(".comment-btn");
const shareButtons = document.querySelectorAll(".share-btn");
const uploadInput = document.getElementById("videoUpload");

videos.forEach(video => {
  video.addEventListener("click", () => video.paused ? video.play() : video.pause());
});

likeButtons.forEach(button => {
  button.addEventListener("click", () => {
    const count = button.querySelector("span");
    let likes = Number(count.textContent);
    if (button.classList.toggle("liked")) likes++;
    else likes--;
    count.textContent = likes;
  });
});

commentButtons.forEach(button => {
  button.addEventListener("click", () => {
    const comment = prompt("Write a comment:");
    if (comment && comment.trim()) {
      const count = button.querySelector("span");
      count.textContent = Number(count.textContent) + 1;
    }
  });
});

shareButtons.forEach(button => {
  button.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(location.href);
      alert("Beyond link copied!");
    } catch {
      alert("Copy the page address to share Beyond.");
    }
  });
});

function openUpload() {
  uploadInput.click();
}
document.getElementById("uploadBtn").addEventListener("click", openUpload);
document.getElementById("createBtn").addEventListener("click", openUpload);

uploadInput.addEventListener("change", event => {
  const file = event.target.files[0];
  if (!file) return;
  const url = URL.createObjectURL(file);
  const card = document.createElement("section");
  card.className = "video-card";
  card.innerHTML = `
    <video class="video" src="${url}" loop muted playsinline autoplay></video>
    <div class="video-info"><h3>@You</h3><p>Your new Beyond video 🎬</p><p>🎵 Original sound</p></div>
    <div class="video-actions">
      <button class="action like-btn">❤️ <span>0</span></button>
      <button class="action comment-btn">💬 <span>0</span></button>
      <button class="action share-btn">↗️</button>
    </div>`;
  document.getElementById("feed").prepend(card);
  window.location.hash = "";
  card.scrollIntoView({behavior:"smooth"});
  attachCardEvents(card);
});

function attachCardEvents(card) {
  const video = card.querySelector(".video");
  video.addEventListener("click", () => video.paused ? video.play() : video.pause());
  card.querySelector(".like-btn").addEventListener("click", e => {
    const b=e.currentTarget,c=b.querySelector("span");let n=Number(c.textContent);
    if(b.classList.toggle("liked"))n++;else n--;c.textContent=n;
  });
  card.querySelector(".comment-btn").addEventListener("click", e => {
    const text=prompt("Write a comment:");
    if(text&&text.trim())e.currentTarget.querySelector("span").textContent=Number(e.currentTarget.querySelector("span").textContent)+1;
  });
  card.querySelector(".share-btn").addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(location.href); alert("Beyond link copied!"); }
    catch { alert("Copy the page address to share Beyond."); }
  });
}

document.getElementById("searchBtn").addEventListener("click", () => {
  const q=document.getElementById("searchInput").value.trim();
  if(q) alert(`Searching Beyond for "${q}"`);
});

document.getElementById("loginBtn").addEventListener("click", () => {
  alert("Login is coming in the next version of Beyond.");
});

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    const video=entry.target.querySelector("video");
    if(entry.isIntersecting) video.play().catch(()=>{});
    else video.pause();
  });
},{threshold:.65});
document.querySelectorAll(".video-card").forEach(card=>observer.observe(card));
